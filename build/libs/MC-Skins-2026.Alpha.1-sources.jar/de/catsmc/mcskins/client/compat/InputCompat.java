package de.catsmc.mcskins.client.compat;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.logging.LogUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import org.slf4j.Logger;

/**
 * Input constants that Minecraft renumbered between 26.1/26.2 and 26.3.
 *
 * <p>26.1/26.2 report GLFW codes ({@code KEY_ESCAPE = 256}, left button {@code 0}), 26.3 switched
 * to HID usage codes ({@code KEY_ESCAPE = 41}, left button {@code 1}). Because
 * {@code InputConstants} fields are {@code static final} compile-time constants, javac inlines
 * their value into the bytecode: a jar built against one release would silently bind every hotkey
 * and mouse button to the wrong code on the other releases. Reading them through reflection keeps
 * the value of the version that is actually running.
 */
public final class InputCompat {
	private static final Logger LOGGER = LogUtils.getLogger();

	public static final int MOUSE_BUTTON_LEFT = read("MOUSE_BUTTON_LEFT", 0);
	public static final int MOUSE_BUTTON_RIGHT = read("MOUSE_BUTTON_RIGHT", 1);
	public static final int MOUSE_BUTTON_MIDDLE = read("MOUSE_BUTTON_MIDDLE", 2);

	public static final int KEY_1 = read("KEY_1", 49);
	public static final int KEY_8 = read("KEY_8", 56);
	public static final int KEY_ESCAPE = read("KEY_ESCAPE", 256);
	public static final int KEY_EQUALS = read("KEY_EQUALS", 61);
	public static final int KEY_ADD = read("KEY_ADD", 334);
	public static final int KEY_MINUS = read("KEY_MINUS", 45);
	public static final int KEY_B = read("KEY_B", 66);
	public static final int KEY_E = read("KEY_E", 69);
	public static final int KEY_F = read("KEY_F", 70);
	public static final int KEY_I = read("KEY_I", 73);
	public static final int KEY_R = read("KEY_R", 82);

	private InputCompat() {
	}

	/** Reads one constant; the fallback matches the GLFW numbering used up to 26.2. */
	private static int read(String name, int fallback) {
		try {
			Field field = InputConstants.class.getField(name);
			if (!Modifier.isStatic(field.getModifiers())) {
				throw new NoSuchFieldException(name);
			}
			return field.getInt(null);
		} catch (ReflectiveOperationException | RuntimeException exception) {
			LOGGER.error("MC-Skins: InputConstants.{} no longer exists, assuming {}.", name, fallback);
			return fallback;
		}
	}
}
